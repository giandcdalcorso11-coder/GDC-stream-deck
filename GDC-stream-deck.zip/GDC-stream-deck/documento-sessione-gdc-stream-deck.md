# Documento di Sessione — GDC Stream Deck

**Versione:** 2
**Ultimo aggiornamento:** 2026-11-26 08:10

## Vision

Trasformare un vecchio iPad Air 1 (iOS 12.5.8, 16 GB) in un pannello da scrivania collegato al PC Windows:
orologio, controllo di Spotify (app desktop) e pulsanti personalizzabili in stile Stream Deck. La pagina web
deve girare su Safari 12 (solo JavaScript ES5, CSS senza funzioni moderne) e la configurazione dei pulsanti
deve essere modificabile da file, senza toccare il codice. Il pannello deve restare sempre acceso in carica.

## Pipeline

Regola generale: ogni parte lato Windows va verificata su un PC Windows vero prima di considerarla chiusa,
perché finora è stata provata solo in modalità simulata su Linux.

### Step 1 — Prima versione (server + pagina)

**Stato:** completato

**Obiettivo:** server Python (solo libreria standard) e pagina ES5 con orologio, stato CPU/RAM, Spotify e pulsanti.

**Decisioni progettuali:** vedi storico sessioni (pagina web invece di app nativa; titolo finestra per leggere Spotify).

**Criterio di completamento:** pagina verificata in orizzontale e verticale (1024×768 e 768×1024), sintassi ES5 controllata con un parser.

**Note (cronologia dello step):**
- [2026-11-25] Prima versione scritta, provata su Linux in modalità simulata e caricata nel repo.

### Step 2 — Verifica su PC Windows

**Stato:** da fare

**Obiettivo:** confermare che sul PC Windows funzionino lettura di Spotify, tasti multimediali, scorciatoie e avvio programmi.

**Decisioni progettuali:** il server accetta POST solo con `Content-Type: application/json` (protezione da comandi inviati da altri siti).

**Criterio di completamento:** conferma dell'utente dopo la prova di: brano e artista corretti, tasti multimediali, almeno un pulsante per tipo (`hotkey`, `url`, `run`, `lock`).

**Note (cronologia dello step):**
- [2026-11-25] Da fare al primo avvio sul PC; nessun esito ancora.
- [2026-11-26] Revisione del codice Windows fatta a tavolino (nessun difetto trovato nelle chiamate ctypes, tasti e CPU/RAM), ma ancora non provato su Windows vero.

### Step 3 — Prova su iPad e avvio automatico

**Stato:** da fare

**Obiettivo:** verificare il pannello sull'iPad Air 1 reale (Safari 12), con Home, Blocco automatico su Mai e Accesso Guidato.

**Decisioni progettuali:** nessuna app nativa; si usa solo il collegamento Home creato da Safari (Condividi → Aggiungi a Home).

**Criterio di completamento:** il pannello resta aperto in carica e si ricollega da solo quando il PC si riaccende.

**Note (cronologia dello step):**
- [2026-11-25] Da fare.
- [2026-11-26] L'utente conferma: nessuna app nativa, solo collegamento Home da Safari.

### Step 4 — Copertina Spotify (opzionale)

**Stato:** da fare

**Obiettivo:** mostrare la copertina del brano tramite le API di Spotify.

**Decisioni progettuali:** nessuna ancora (richiede di creare un'app sviluppatore Spotify).

**Criterio di completamento:** copertina visibile sul pannello.

**Note (cronologia dello step):**
- [2026-11-25] Proposto all'utente, non ancora deciso.

## Storico sessioni

### [2026-11-26 08:10] Revisione del codice per Windows e rafforzamento del server

**Riepilogo:** letti `server.py` e `web/` per cercare problemi su Windows/iOS 12 e aggiunte due protezioni al server; l'utente ha confermato che sull'iPad si userà solo il collegamento Home da Safari.

**Cosa è stato fatto:**
- Revisione di `server.py`, `web/app.js`, `index.html`, `style.css`, `start.bat`, `start_hidden.vbs`: chiamate ctypes, tasti, calcolo CPU, compatibilità ES5/CSS con Safari 12 e `pythonw` senza console risultano corretti leggendo il codice (non provati su Windows).

**Bug: i comandi potevano essere inviati da qualsiasi sito aperto in un browser sulla stessa rete**

**Sintomo:** nessuno osservato; rischio trovato in revisione. Un POST a `/api/press` con tipo `text/plain` veniva accettato e il corpo letto come JSON.
**Causa:** il server non controllava il `Content-Type`, quindi una pagina esterna poteva inviare la richiesta senza controllo preventivo del browser (CORS). Con token vuoto (impostazione predefinita) bastava conoscere l'indirizzo e l'`id` di un pulsante.
**Fix applicato:** i POST senza `application/json` ricevono 415; corpo massimo 4096 byte (413). Verificato su Linux in modalità simulata: JSON 200, `text/plain` e senza tipo 415.

- Aggiunto "advertisement" ai titoli considerati inattivi, per non mostrare "Advertisement" come brano (ipotesi, da verificare su Spotify vero).

**Decisioni prese:**
- Contesto: lo Step 3 prevedeva avvio sull'iPad.
- Decisione: nessuna app nativa, solo collegamento Home da Safari.
- Alternative scartate: app nativa.
- Da rivedere se: serve l'avvio automatico dopo il riavvio dell'iPad (con questa scelta non è possibile).

**File consegnati/modificati:** `server.py`, `documento-sessione-gdc-stream-deck.md`

**Impatto su Vision/Pipeline:** Step 2 e Step 3 aggiornati (decisioni e note).

---

### [2026-11-26 07:31] Dall'analisi di PhoneBox al pannello per iPad nel repo GDC-stream-deck

**Riepilogo:** PhoneBox (ersinkoc/phonebox) non gira su iPhone 6 e iPad Air 1 (iOS 12), quindi è stato scritto un pannello web su misura per l'iPad Air 1 con orologio, Spotify e pulsanti, poi spostato nel nuovo repo GDC-stream-deck.

**Cosa è stato fatto:**
- Analisi di compatibilità di PhoneBox

**Bug: PhoneBox non utilizzabile su iPhone 6 e iPad Air 1**

**Sintomo:** né l'app né il pannello web di PhoneBox funzionano su iOS 12.
**Causa:** l'app ufficiale è solo Android 5+; il companion iOS è sperimentale e richiede iOS 16+; il pannello web usa `?.` (circa 400 volte), `??`, `replaceAll`, `@container`, `color-mix` e altro, non supportati da Safari 12. Dedotta leggendo il codice, non provata su un dispositivo vero.
**Fix applicato:** nessuno su PhoneBox; si è scelto un pannello nuovo (vedi Decisioni).

- Pannello scritto: `server.py` (Python, libreria standard, HTTP sulla rete locale), pagina ES5 in `web/`, pulsanti in `buttons.json` (azioni `hotkey`, `media`, `url`, `run`, `lock`; l'iPad può eseguire solo pulsanti presenti nel file; token opzionale).
- Spotify letto dal titolo della finestra di Spotify.exe; controlli via tasti multimediali di Windows.
- Provato su Linux in modalità simulata (`PANEL_DEMO=1`), con screenshot in orizzontale e verticale e controllo ES5 con acorn.
- Spostato dal repo GDC-DASHBOARD (branch `claude/intelligent-heisenberg-nspzk5`) a GDC-stream-deck (branch `main`, repo prima vuoto); la copia in GDC-DASHBOARD è stata cancellata su richiesta.
- Consigli su uso sempre in carica: consumo stimato di 3-4 kWh al mese (stima, non misura); rischio principale è l'usura della batteria del 2013 perché iOS 12 non ha la ricarica ottimizzata; lo schermo LCD non ha burn-in.

**Decisioni prese:**
- Contesto: PhoneBox non è utilizzabile sull'iPad e l'utente vuole Spotify, orologio e pulsanti personalizzabili.
- Decisione: pagina web ES5 servita da un server Python sul PC Windows, aperta in Safari e aggiunta alla Home.
- Alternative scartate: app nativa (iOS 12 non è supportato dagli strumenti attuali); polyfill/transpiling del pannello PhoneBox (circa 4,4 MB di codice, il progetto non lo prevede); Duet Display e Spacedesk (non erano la richiesta, solo citati).
- Da rivedere se: l'iPad viene sostituito con un dispositivo con iOS recente, o servono funzioni che la lettura via titolo finestra non dà (copertina, posizione nel brano).

**Limiti noti:** l'avvio automatico all'accensione non è possibile su iOS 12 (serve toccare l'icona dopo un riavvio); le parti Windows non sono ancora state provate su un PC Windows vero.

**File consegnati/modificati:**
- Creati nel repo GDC-stream-deck: `server.py`, `buttons.json`, `start.bat`, `start_hidden.vbs`, `README.md`, `web/index.html`, `web/style.css`, `web/app.js`, `documento-sessione-gdc-stream-deck.md`
- GDC-DASHBOARD: aggiunta e poi rimossa la cartella `ipad-panel/` (commit nella cronologia del branch)

---
